# notable_signals.R
# ----------------------------------------------------------------------------
# Sweeps ALL numeric time series across ALL uploaded ONS Excel files,
# computes z-scores for the latest period's change vs the trailing 24 months,
# and returns a ranked data frame of notable movements.
#
# Completely self-contained — no DB required, works offline.
# Uses only: readxl, dplyr, lubridate (already loaded by helpers.R)
# ----------------------------------------------------------------------------

suppressPackageStartupMessages({
  library(readxl)
  library(dplyr)
  library(lubridate)
})

# ----------------------------------------------------------------------------
# ONS dataset identifier code -> plain English label lookup
# Covers the main series from A01, HR1, RTISA, X09.
# Falls back to the raw code if not found.
# ----------------------------------------------------------------------------
.ons_code_labels <- c(
  # A01 Sheet 1 — main LFS series
  "MGRZ" = "Employment level (16+, 000s)",
  "MGSR" = "Employment rate (16-64, %)",
  "MGSC" = "Unemployment level (16+, 000s)",
  "MGSX" = "Unemployment rate (16+, %)",
  "MGSF" = "Economic activity level (16+, 000s)",
  "MGWG" = "Economic activity rate (16-64, %)",
  "MGSI" = "Inactivity level (16-64, 000s)",
  "YBTC" = "Inactivity rate (16-64, %)",
  "LF2G" = "Employment level (16+, 000s) [LF2G]",
  "LF24" = "Employment rate (16-64, %) [LF24]",
  "LF2Q" = "Unemployment level (16-64, 000s)",
  "LF2S" = "Inactivity level (16-64, 000s)",
  # A01 Sheet 2 — age breakdown
  "YBTO" = "Employment level 16-17 (000s)",
  "YBTR" = "Employment level 18-24 (000s)",
  "YBTU" = "Employment level 25-34 (000s)",
  "YBTX" = "Employment level 35-49 (000s)",
  "LF26" = "Employment level 50-64 (000s)",
  "LFK4" = "Employment level 65+ (000s)",
  "YBUA" = "Employment rate 16-17 (%)",
  "YBUD" = "Employment rate 18-24 (%)",
  "YBUG" = "Employment rate 25-34 (%)",
  "YBUJ" = "Employment rate 35-49 (%)",
  "LF2U" = "Employment rate 50-64 (%)",
  "LFK6" = "Employment rate 65+ (%)",
  "YBVH" = "Unemployment level 16-17 (000s)",
  "YBVN" = "Unemployment level 18-24 (000s)",
  "YCGM" = "Unemployment level 25-34 (000s)",
  "YCGS" = "Unemployment level 35-49 (000s)",
  "LF28" = "Unemployment level 50-64 (000s)",
  "K5HU" = "Unemployment level 65+ (000s)",
  "YBVK" = "Unemployment rate 16-17 (%)",
  "YBVQ" = "Unemployment rate 18-24 (%)",
  "YCGP" = "Unemployment rate 25-34 (%)",
  "YCGV" = "Unemployment rate 35-49 (%)",
  "LF2E" = "Unemployment rate 50-64 (%)",
  "K5HW" = "Unemployment rate 65+ (%)",
  # A01 AWE sheets (13, 15)
  "KAB9" = "AWE total pay — whole economy (£/week)",
  "KAC2" = "AWE total pay YoY — whole economy (%)",
  "KAC3" = "AWE total pay YoY 3m avg — whole economy (%)",
  "KAI7" = "AWE regular pay — whole economy (£/week)",
  "KAI8" = "AWE regular pay YoY — whole economy (%)",
  "KAI9" = "AWE regular pay YoY 3m avg — whole economy (%)",
  "KAC6" = "AWE total pay YoY — private sector (%)",
  "KAC9" = "AWE total pay YoY — public sector (%)",
  "KAJ7" = "AWE regular pay YoY — public sector (%)",
  # A01 Sheet 19 — vacancies
  "AP2Y" = "Vacancies (000s) — all industries",
  # HR1 — redundancies
  "BEAO" = "Redundancy rate (per 1,000 employees)",
  "BEAP" = "Redundancy level (000s)",
  # RTISA — payrolled employees
  "PGMJ" = "Payrolled employees (000s)",
  "PGMK" = "Payrolled employees change on month (000s)",
  # X09 — AWE real CPI adjusted
  "KAB8" = "AWE total pay real (CPI-adjusted, £/week)"
)

.label_for_code <- function(code) {
  lbl <- .ons_code_labels[code]
  if (is.na(lbl)) code else unname(lbl)
}

# ----------------------------------------------------------------------------
# Extract all time series from a single Excel sheet.
# Returns a list of lists: list(dates = Date[], values = numeric[], label = chr)
# Skips columns with fewer than 6 non-NA numeric values.
# ----------------------------------------------------------------------------
.extract_series_from_sheet <- function(path, sheet_name, file_label) {
  raw <- tryCatch(
    suppressMessages(readxl::read_excel(path, sheet = sheet_name,
                                        col_names = FALSE, n_max = 500)),
    error = function(e) NULL
  )
  if (is.null(raw) || nrow(raw) < 4 || ncol(raw) < 2) return(list())

  # Find the header rows: scan top 15 rows for ONS dataset identifier codes
  # (4 uppercase letters or mix like LF2G, KAB9 — typically row 4 in A01)
  code_row  <- NULL
  date_col  <- 1L

  for (ri in 1:min(15, nrow(raw))) {
    row_vals <- as.character(unlist(raw[ri, ]))
    # A row where most non-NA cells look like ONS codes (3-6 chars, uppercase/digits)
    non_na   <- row_vals[!is.na(row_vals) & nzchar(row_vals)]
    if (length(non_na) < 2) next
    looks_like_code <- grepl("^[A-Z][A-Z0-9]{2,5}$", non_na)
    if (sum(looks_like_code) / length(non_na) > 0.4) {
      code_row <- ri
      break
    }
  }

  # Find the date column: first column whose values parse as dates for
  # the majority of rows after the header
  data_start <- if (!is.null(code_row)) code_row + 1L else 2L

  date_candidates <- raw[data_start:nrow(raw), 1][[1]]
  dates <- tryCatch({
    s   <- as.character(date_candidates)
    num <- suppressWarnings(as.numeric(s))
    is_serial <- !is.na(num) & grepl("^[0-9]+\\.?[0-9]*$", s)
    out <- rep(as.Date(NA), length(s))
    if (any(is_serial))  out[is_serial]  <- as.Date(num[is_serial], origin = "1899-12-30")
    if (any(!is_serial)) out[!is_serial] <- suppressWarnings(
      as.Date(lubridate::parse_date_time(
        s[!is_serial],
        orders = c("ymd", "mdy", "dmy", "bY", "BY", "Y b", "b Y", "Ym", "my")
      ))
    )
    floor_date(as.Date(out), "month")
  }, error = function(e) rep(as.Date(NA), nrow(raw) - data_start + 1))

  # Need at least 26 valid dates to compute z-scores over 24 months + latest
  valid_date_idx <- which(!is.na(dates))
  if (length(valid_date_idx) < 26) return(list())

  series_list <- list()

  for (col_idx in 2:ncol(raw)) {
    # Get code label from code_row if available
    code <- if (!is.null(code_row)) {
      trimws(as.character(raw[[col_idx]][code_row]))
    } else NA_character_

    raw_vals <- raw[data_start:nrow(raw), col_idx][[1]]
    nums <- suppressWarnings(as.numeric(as.character(raw_vals)))

    # Need enough non-NA numeric values
    valid_idx <- which(!is.na(nums) & !is.na(dates))
    if (length(valid_idx) < 26) next

    # Check it's actually numeric data (not mostly zeros or constants)
    valid_nums <- nums[valid_idx]
    if (sd(valid_nums, na.rm = TRUE) < 1e-10) next

    # Build clean aligned series
    d <- dates[valid_idx]
    v <- valid_nums

    # Sort by date
    ord <- order(d)
    d <- d[ord]
    v <- v[ord]

    # Use a code label if we have one, else construct from file+sheet+col
    if (!is.na(code) && nzchar(code) && grepl("^[A-Z][A-Z0-9]{2,5}$", code)) {
      label <- paste0(.label_for_code(code),
                      " [", code, "] — ", file_label, " / ", sheet_name)
    } else {
      label <- paste0(file_label, " / ", sheet_name, " — col ", col_idx)
    }

    series_list[[length(series_list) + 1]] <- list(
      dates  = d,
      values = v,
      label  = label,
      code   = if (!is.na(code)) code else NA_character_
    )
  }

  series_list
}

# ----------------------------------------------------------------------------
# Compute z-score for the latest period's month-on-month change,
# using the trailing `history_months` periods as the reference distribution.
# Returns NA if insufficient data.
# ----------------------------------------------------------------------------
.compute_zscore <- function(dates, values, history_months = 24L) {
  n <- length(values)
  if (n < history_months + 2L) return(list(z = NA_real_, latest_val = NA_real_,
                                           latest_change = NA_real_, period = NA_character_))

  # Month-on-month changes
  changes <- diff(values)
  change_dates <- dates[-1]

  n_ch <- length(changes)
  if (n_ch < history_months + 1L) return(list(z = NA_real_, latest_val = NA_real_,
                                              latest_change = NA_real_, period = NA_character_))

  latest_change <- changes[n_ch]
  history       <- changes[max(1L, n_ch - history_months):(n_ch - 1L)]

  mu  <- mean(history, na.rm = TRUE)
  sig <- sd(history,   na.rm = TRUE)

  if (is.na(sig) || sig < 1e-10) return(list(z = NA_real_, latest_val = NA_real_,
                                              latest_change = NA_real_, period = NA_character_))

  z <- (latest_change - mu) / sig

  list(
    z             = z,
    latest_val    = values[n],
    latest_change = latest_change,
    period        = format(dates[n], "%b %Y")
  )
}

# ----------------------------------------------------------------------------
# Main entry point.
# uploaded_files: named list with elements a01, hr1, x09, rtisa, cla01, x02
#                 (any can be NULL)
# history_months: number of months to use for the reference distribution
# top_n:          max rows to return
# min_z:          minimum absolute z-score to include (filters out noise)
#
# Returns a data frame with columns:
#   label, period, latest_val, latest_change, z_score, flag
# ----------------------------------------------------------------------------
run_notable_signals <- function(
  uploaded_files,
  history_months = 24L,
  top_n          = 15L,
  min_z          = 1.5
) {

  file_map <- list(
    A01   = uploaded_files$a01,
    HR1   = uploaded_files$hr1,
    X09   = uploaded_files$x09,
    RTISA = uploaded_files$rtisa,
    CLA01 = uploaded_files$cla01,
    X02   = uploaded_files$x02
  )
  file_map <- Filter(Negate(is.null), file_map)

  if (length(file_map) == 0) return(data.frame())

  all_series <- list()

  for (file_label in names(file_map)) {
    path <- file_map[[file_label]]
    if (!file.exists(path)) next

    sheets <- tryCatch(readxl::excel_sheets(path), error = function(e) character(0))
    # Skip sheets that are clearly metadata or notes
    sheets <- sheets[!grepl("(?i)^(note|intro|content|cover|read|info|legend|source|meta)", sheets)]

    for (sh in sheets) {
      series <- .extract_series_from_sheet(path, sh, file_label)
      all_series <- c(all_series, series)
    }
  }

  if (length(all_series) == 0) return(data.frame())

  # Compute z-score for each series
  results <- lapply(all_series, function(s) {
    zr <- .compute_zscore(s$dates, s$values, history_months)
    if (is.na(zr$z)) return(NULL)
    data.frame(
      label         = s$label,
      period        = zr$period,
      latest_val    = zr$latest_val,
      latest_change = zr$latest_change,
      z_score       = zr$z,
      stringsAsFactors = FALSE
    )
  })

  results <- Filter(Negate(is.null), results)
  if (length(results) == 0) return(data.frame())

  df <- do.call(rbind, results)

  # Remove duplicates — same code/label can appear across sheets
  df <- df[!duplicated(df$label), ]

  # Filter to notable only and rank by absolute z-score
  df <- df[abs(df$z_score) >= min_z, ]
  if (nrow(df) == 0) return(data.frame())

  df <- df[order(abs(df$z_score), decreasing = TRUE), ]
  df <- head(df, top_n)

  # Add traffic light flag
  df$flag <- ifelse(abs(df$z_score) >= 3, "red",
              ifelse(abs(df$z_score) >= 2, "amber", "yellow"))

  df
}
